<div class="container">
<div class="row">
	<div class="col-3">
		<div class="list-group ">
  			<a href="<?php echo base_url()?>Ccustomer/profile" type="button" class="list-group-item list-group-item-action">Dashboard Akun</a>
			<a href="<?php echo base_url()?>Ccustomer/informasi_akun/<?= $pengguna->idUser?>" type="button" class="list-group-item list-group-item-action">Informasi Akun</a>
			<a href="<?php echo base_url()?>Ccustomer/buku_alamat" type="button" class="list-group-item list-group-item-action">Buku Alamat</a>
			<a href="<?php echo base_url()?>Ccustomer/pesanan" type="button" class="list-group-item list-group-item-action">Pesanan Saya</a>
			<a href="<?php echo base_url()?>Ccustomer/newslatter" type="button" class="list-group-item list-group-item-action">berlangganan newslatter</a>
			<a href="<?php echo base_url() ?>Ccustomer/ulasan" type="button" class="list-group-item list-group-item-action active">Ulasan Produk</a>
			<a href="<?php echo base_url() ?>Ccustomer/wishlist" type="button" class="list-group-item list-group-item-action ">Wishlist</a>      			
		</div>
	</div>
	<div class="col">
		<h2>Detil Ulasan</h2>
		<div class="bawah bg-primary"></div>
		<div class="row mt-3 ">
			<div class="col mt-3">
        <div class="row">
            <div class="col-5">
                <img src="<?php echo base_url() ?>assets/gambar/1.jpg">
            </div>
            <div class="col">
                <h3>Nama Barang</h3>
            </div>
        </div>
        
        <div class="row">
            <div class="col">
                <h4>tas</h4>
                <p>isi Ulasan</p>
                <p>Tanggal mengulas</p>
            </div>
        </div>

        <div class="row mt-5">
                        <div class="col text-right">
                <a href="<?= base_url(); ?>Ccustomer/ulasan"><small class="col-4">Back To My Reviews</small></a>
            </div>
        </div>
		</div>		
	</div>
</div>
</div>
</div>