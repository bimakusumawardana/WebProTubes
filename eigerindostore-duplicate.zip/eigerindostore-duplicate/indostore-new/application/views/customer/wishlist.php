<div class="container">
<div class="row">
	<div class="col-3">
		<div class="list-group ">
  			<a href="<?php echo base_url()?>Ccustomer/profile" type="button" class="list-group-item list-group-item-action">Dashboard Akun</a>
			<a href="<?php echo base_url()?>Ccustomer/informasi_akun/<?= $pengguna->idUser?>" type="button" class="list-group-item list-group-item-action">Informasi Akun</a>
			<a href="<?php echo base_url()?>Ccustomer/buku_alamat" type="button" class="list-group-item list-group-item-action">Buku Alamat</a>
			<a href="<?php echo base_url()?>Ccustomer/pesanan" type="button" class="list-group-item list-group-item-action">Pesanan Saya</a>
			<a href="<?php echo base_url()?>Ccustomer/newslatter" type="button" class="list-group-item list-group-item-action">berlangganan newslatter</a>
			<a href="<?php echo base_url() ?>Ccustomer/ulasan" type="button" class="list-group-item list-group-item-action">Ulasan Produk</a>
			<a href="<?php echo base_url() ?>Ccustomer/wishlist" type="button" class="list-group-item list-group-item-action active">Wishlist</a>      		
		</div>
	</div>
	<div class="col">
		<h2>Detil Ulasan</h2>
		<div class="bawah bg-primary"></div>
		<div class="row mt-3 ">
			<div class="col mt-3">

                <!-- jika data kosong tampil kan ini

                <div class="row">
                    <div class="col">
                        <p class="bg-warning pd-1">Anda belum pernah membuat wishlist.</p>
                    </div>
                </div>

                sampai disini -->


                <!-- jika data ada tampilkan ini -->

        <div class="row text-center">
            <div class="col-4">
                <img src="<?php echo base_url() ?>assets/gambar/1.jpg" style="width: 200px; height: 200px;">
                <p>Nama Produk</p>
                <p>Harga Produk</p>
                <div class="row">
                    <div class="col-2">
                        <p>Jumlah</p>
                    </div>
                    <div class="col">
                        <input type="text" name="banyak">
                    </div>
                </div>
                <div class="row ">
                    <div class="col-9 mt-1 ">
                       <button type="submit" name="tambah" class="btn btn-primary btn-block">TAMBAH KE KERANJANG</button>
                    </div>
                </div>
                 <div class="row text-left">
                    <div class="col-9 mt-1 ">
                       <a href="#"><small class="col-4">Hapus</small></a>
                    </div>
                </div>               
            </div>

            <div class="col-4">
                <img src="<?php echo base_url() ?>assets/gambar/1.jpg" style="width: 200px; height: 200px;">
                <p>Nama Produk</p>
                <p>Harga Produk</p>
                <div class="row">
                    <div class="col-2">
                        <p>Jumlah</p>
                    </div>
                    <div class="col">
                        <input type="text" name="banyak">
                    </div>
                </div>
                <div class="row ">
                    <div class="col-9 mt-1 ">
                       <button type="submit" name="tambah" class="btn btn-primary btn-block">TAMBAH KE KERANJANG</button>
                    </div>
                </div>
                 <div class="row text-left">
                    <div class="col-9 mt-1 ">
                       <a href="#"><small class="col-4">Hapus</small></a>
                    </div>
                </div>               
            </div>



        </div>

        <div class="row mt-5">
                        <div class="col text-right">
                <a href="<?= base_url(); ?>Ccustomer/profile"><small class="col-4">Kembali</small></a>
            </div>
        </div>
		</div>		
	</div>
</div>
</div>
</div>