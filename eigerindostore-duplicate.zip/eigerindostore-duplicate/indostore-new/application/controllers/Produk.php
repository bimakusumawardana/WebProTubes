<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Produk extends CI_Controller {

	public function index()
	{
		
	}

}

/* End of file Produk.php */
/* Location: ./application/controllers/Produk.php */